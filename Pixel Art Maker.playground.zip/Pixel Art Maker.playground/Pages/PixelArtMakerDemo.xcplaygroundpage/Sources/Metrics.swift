import UIKit

public struct Metrics {
	public static let regular: CGFloat = 20
	public static let large: CGFloat = 30
}
